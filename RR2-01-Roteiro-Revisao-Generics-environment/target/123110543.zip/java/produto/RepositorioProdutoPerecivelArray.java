package produto;

public class RepositorioProdutoPerecivelArray extends RepositorioProdutosArray<ProdutoPerecivel> {

	public RepositorioProdutoPerecivelArray(int size) {
		super(size);
	}
}
