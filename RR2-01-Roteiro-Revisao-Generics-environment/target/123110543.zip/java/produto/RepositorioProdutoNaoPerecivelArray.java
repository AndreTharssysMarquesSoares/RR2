package produto;

public class RepositorioProdutoNaoPerecivelArray extends RepositorioProdutosArray<ProdutoPerecivel>{

	public RepositorioProdutoNaoPerecivelArray(int size) {
		super(size);
	}

}